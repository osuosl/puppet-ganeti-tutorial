# A stub class, so our constants work.
class Puppet::Indirector::Status
end
