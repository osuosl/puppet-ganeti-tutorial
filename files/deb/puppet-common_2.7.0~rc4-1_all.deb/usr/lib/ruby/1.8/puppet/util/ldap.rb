#
#  Created by Luke Kanies on 2008-3-23.
#  Copyright (c) 2008. All rights reserved.
module Puppet::Util::Ldap
end
