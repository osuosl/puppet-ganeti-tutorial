require 'puppet/indirector/status'
require 'puppet/indirector/rest'

class Puppet::Resource::Rest < Puppet::Indirector::REST
end
