#
#  Created by Luke Kanies on 2007-10-16.
#  Copyright (c) 2007. All rights reserved.

# Just a stub class.
class Puppet::FileServing # :nodoc:
end
