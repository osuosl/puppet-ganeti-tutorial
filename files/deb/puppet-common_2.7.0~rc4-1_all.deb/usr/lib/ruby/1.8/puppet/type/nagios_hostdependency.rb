require 'puppet/util/nagios_maker'

Puppet::Util::NagiosMaker.create_nagios_type :hostdependency
