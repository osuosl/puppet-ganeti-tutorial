=================
Ganeti 2.5 design
=================

The following design documents have been implemented in Ganeti 2.5:

- :doc:`design-lu-generated-jobs`
- :doc:`design-chained-jobs`
- :doc:`design-multi-reloc`
- :doc:`design-shared-storage`

.. vim: set textwidth=72 :
.. Local Variables:
.. mode: rst
.. fill-column: 72
.. End:
