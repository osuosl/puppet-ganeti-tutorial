from ganeti_web.tests.views.cluster import *
from ganeti_web.tests.views.node import *
from ganeti_web.tests.views.virtual_machine import *
from ganeti_web.tests.views.vm_template import *
