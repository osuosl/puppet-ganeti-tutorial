from ganeti_web.tests.forms.virtual_machine.actions import *
from ganeti_web.tests.forms.virtual_machine.create import *
from ganeti_web.tests.forms.virtual_machine.modify import *