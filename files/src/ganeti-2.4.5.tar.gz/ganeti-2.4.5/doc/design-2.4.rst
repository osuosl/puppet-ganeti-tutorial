=================
Ganeti 2.4 design
=================

The following design documents have been implemented in Ganeti 2.4:

- :doc:`design-oob`
- :doc:`design-query2`

.. vim: set textwidth=72 :
.. Local Variables:
.. mode: rst
.. fill-column: 72
.. End:
