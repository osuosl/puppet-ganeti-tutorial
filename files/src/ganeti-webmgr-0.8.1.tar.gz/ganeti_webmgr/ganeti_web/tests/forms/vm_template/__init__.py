from ganeti_web.tests.forms.vm_template.create import *
from ganeti_web.tests.forms.vm_template.copy import *
