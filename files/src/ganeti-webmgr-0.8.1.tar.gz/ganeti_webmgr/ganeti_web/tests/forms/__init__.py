from ganeti_web.tests.forms.cluster import *
from ganeti_web.tests.forms.virtual_machine import *
from ganeti_web.tests.forms.vm_template import *
